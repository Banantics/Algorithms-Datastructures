#include "merge_sort.h"
#include "stdio.h"

size_t g_compares = 0;

node_t *split(node_t *phead) {
    node_t *fast = phead->next;
    node_t *slow = phead;
    while (fast != NULL && fast->next != NULL) {
        fast = fast->next->next;
        slow = slow->next;
    }
    node_t *newHead = slow->next; // The head of the second half of the list.
    slow->next = NULL; // Split the list by terminating the first half.
    return newHead;
}


    // TODO (Activity 6): complete the code
    //  cut the list in two halves at the right
    //  you don't have to create any new nodes for this


node_t *merge(node_t *a, node_t *b) {
     // Printing some handy debug information


    // this function reconstructs a linked list from the two linked lists a and b.
    // sentinel will be used as a "fake" head of the resulting list, nodes from node sequences a and b will be appended to sentinel.
    node_t sentinel = {.next = NULL};
    node_t *result = &sentinel;         // result always points to the last node in the sequence we're constructing
    (void) result;  // remove this line when you've implemented this function
    while (a != NULL && b != NULL) {
        g_compares++;   // a comparison is made, count it
        if (a->value < b->value) {
            // TODO (Activity 7): append a to our result
            result->next = a;
            a = a->next;
        } else {
            // TODO (Activity 7): append b to our result
          result->next =  b;
            b = b->next;
        }
         result = result->next;
        // TODO: let result again point to the last node in the list
    }
    // Either a or b will be NULL at this point this is the left over
    if(a!= NULL) {
        result->next = a;
    }
    if(b != NULL){
        result->next = b;
    }
    // TODO (Activity 7): append the remaining node sequence to the result
    return sentinel.next;   // return the sequence of nodes we've constructed
}

node_t *merge_sort(node_t *first) {
    // TODO (Activity 8) : complete the code
    if (first->next == NULL) return first;  // no need to sort a list with one element

    // TODO: split first into two lists,
node_t *second_half_split = split(first);

        //  merge_sort these two lists, and then merge them together again
     node_t *sorted_first_half = merge_sort(first);
     node_t *sorted_second_half= merge_sort(second_half_split);



    //  Finally, return the first element of the sorted list
    return merge(sorted_second_half,sorted_first_half);
}

void list_sort(list_t *plist) {
    if (plist->head != NULL) plist->head = merge_sort(plist->head);
}
