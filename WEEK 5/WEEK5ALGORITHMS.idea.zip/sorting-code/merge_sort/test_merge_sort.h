#ifndef SORTING_TEST_MERGE_SORT_H
#define SORTING_TEST_MERGE_SORT_H

void test_split(void);

void test_merge(void);

void test_merge_sort(void);

#endif //SORTING_TEST_MERGE_SORT_H
