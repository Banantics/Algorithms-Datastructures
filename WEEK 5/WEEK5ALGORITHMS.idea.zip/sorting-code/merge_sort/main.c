#include <stdio.h>
#include <sortinglib/list.h>
#include "merge_sort.h"
#include "test_merge_sort.h"

// The global var g_compares is defined externally, in merge_sort.c
// Declaring it as "extern" allows us to use that variable here as well
extern size_t g_compares;

/// Part II - Merge sort

int main(void) {
    test_split();
    test_merge();


    list_t list;
    list_init(&list);

    g_compares = 0; // reset nr. of comparisons
    // build list of these 6 elements

       // merge-sort list

    // print some handy information
    for (int i = 10000; i > 0; --i) list_append(&list, i);
    list_sort(&list);

    node_sequence_print(list.head);
    printf(": %zu comparisons\n", g_compares);

    // cleanup
    list_destroy(&list);
    return 0;
}
