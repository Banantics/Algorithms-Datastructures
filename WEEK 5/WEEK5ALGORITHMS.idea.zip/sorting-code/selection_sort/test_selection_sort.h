#ifndef SORTING_TEST_SELECTION_SORT_H
#define SORTING_TEST_SELECTION_SORT_H

void test_find_min(void);
void test_array_sort(void);

#endif //SORTING_TEST_SELECTION_SORT_H
