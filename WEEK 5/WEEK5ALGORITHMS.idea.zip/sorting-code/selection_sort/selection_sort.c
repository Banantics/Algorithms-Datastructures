#include "selection_sort.h"
#include <limits.h>
size_t g_compares = 0;

int *find_min(int *values, size_t count) {
    (void) values;
    (void) count;
    if (values == NULL) return NULL;
    int *min = values;
    for (size_t i = 1; i < count ; ++i) {
        g_compares++;
        if (*min > values[i]) {
            min = &values[i];
        }
    }
    return min;
}
    // TODO (Activity 2): implement

void array_sort(array_t *array) {
    (void) array;
    g_compares = 0;
    for (size_t i = 0; i < array->count ; ++i) {
            swap(&array->data[i], find_min(&array->data[i],array->count -i));
    }

}
