//
// Created by rgr24 on 22/03/2023.
//

#ifndef SETS_TEST_SET_H
#define SETS_TEST_SET_H

void test_unsorted_set_add(void);
void test_unsorted_set_remove(void);
void test_unsorted_set_contains(void);

#endif //SETS_TEST_SET_H
