#include "set.h"
#include <malloc.h>
#include <math.h>

void set_add(set_t *set, double value) {
    if (!ensure_capacity(set)) return;

    // TODO: add value to the set's data if it is not already present

    if (!set_contains(set, value)) {
        set->data[set->count] = value;
        set->count++;
    } else {
        return;
    }
}

void set_remove(set_t *set, double value) {
    // TODO: remove the value if it's present
    for (size_t i = 0; i < set->count; ++i) {
        if (set->eq_fun(set->data[i],value)) {
            for (size_t j = i; j <set->count-1; ++j) {
                set->data[j] = set->data[j + 1];
            }
            //double temp = set->data[i];
            //set->data[i] = set->data[i+1];
            //set->data[i+1] = temp;
            //set->count--;
            set->count--;
            break;
        }
    }


}

bool set_contains(const set_t *set, double value) {
    // TODO: return true if value is present in the set's data
    for (size_t i = 0; i < set->count; i++) {

        if (set->eq_fun(set->data[i], value)) {
            return true;
        }
    }
    return false;
}

set_t *set_create(size_t init_cap, eq_fun_t fun) {
    return set_init((set_t *) malloc(sizeof(set_t)), init_cap, fun);
}

set_t *set_init(set_t *set, size_t init_cap, eq_fun_t fun) {
    if (set != NULL) {
        set->eq_fun = fun;
        set->data = (double *) malloc(sizeof(double) * init_cap);
        set->count = 0;
        set->capacity = set->data != NULL ? init_cap : 0;
    }
    return set;
}

