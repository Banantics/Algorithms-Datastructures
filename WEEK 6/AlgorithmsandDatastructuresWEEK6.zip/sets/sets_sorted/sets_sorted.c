#include <stdio.h>
#include <math.h>
#include "set.h"
#include "test_set.h"

// global var to keep track of nr. of comparisons in binary search (activity 8)
extern size_t g_comparisons;

int cmp_dbl(double d1, double d2){
    g_comparisons++;

   if (fabs(d1 - d2 ) < 0.0000002673539810) {
       return 0 ;
   } else if (d1 < d2){
       return -1;
   }
    return 1;
}

int main(void) {
    // Part 2 - a set using a sorted array

    // Activity 6
    // TODO: implement function cmp_dbl
    const double a = 41.0 + 0.5 + 0.2 + 0.2 + 0.1;
    const double b = 43.0 - 0.5 - 0.2 - 0.2 - 0.1;
    const double pi_1 = 3.14159265;
    const double pi_2 = 355.0 / 113.0;

     // must print: compare(42.000000, 42.000000) == 0
     printf("compare(%lf, %lf) == %d\n", a, b, cmp_dbl(a, b));
     // must print: compare(42.000000, 42.000000) == 0
     printf("compare(%lf, %lf) == %d\n", b, b, cmp_dbl(b, a));
     // must print: compare(3.1415927, 3.1415929) == -1
     printf("compare(%.7lf, %.7lf) == %d\n", pi_1, pi_2, cmp_dbl(pi_1, pi_2));
     // must print: compare(3.1415929, 3.1415927) == 1
     printf("compare(%.7lf, %.7lf) == %d\n", pi_2, pi_1, cmp_dbl(pi_2, pi_1));

    // Activity 7 - implement set_index_of
    test_sorted_set_index_of();

    // Activity 8 - Time complexity of binary search
    // Array of sizes to test
    int sizes[] = {16, 32, 64, 128, 256, 1000, 4000, 10000, 1048576};
    int num_sizes = sizeof(sizes) / sizeof(sizes[0]);

    for (int i = 0; i < num_sizes; ++i) {
        // Initialize set for current size
        set_t set;
        set_init(&set, sizes[i], cmp_dbl); // Initialize with enough capacity

        // Fill the set with ascending double values
//        for (int j = 0; j < sizes[i]; ++j) {
  //          set_add(&set, j * 1.0);
    //    }

g_comparisons = 0;// Reset comparison count


        // Perform the search for a value known to not be in the set
        // Using a value larger than the largest in the set ensures a full search
        set_index_of(&set, sizes[i] * 1.5); // Search for a value that is not in the set

        // Print the results
        printf("Binary search in %d elements. Nr. of comparisons: %zu\n", sizes[i], g_comparisons);

        // Cleanup
    }

    // Activity 9 - Finalize the set
   test_sorted_set_contains();
    test_sorted_set_add();
    test_sorted_set_remove();

    return 0;
}
