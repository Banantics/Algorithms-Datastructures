//
// Created by rgr24 on 21/03/2023.
//
#include <malloc.h>
#include "set.h"

 size_t g_comparisons = 0;

size_t set_index_of(const set_t *set, double value) {
    // TODO (Activity 7 - implement binary search)
    (void) set;
    (void) value;
    size_t hi = set->count;
    size_t lo;
    for (lo = 0; lo < hi;) {

        size_t mid = lo + (hi - lo) / 2;


        if (set->cmp_fun(set->data[mid], value) < 0) {
            lo = mid + 1;

        } else if (set->cmp_fun(set->data[mid], value) > 0) {
            hi = mid;
        } else {
            return mid;
        }
    }

    return lo;
}

void set_add(set_t *set, double value) {
    if (!ensure_capacity(set)) return;

  size_t finder =  set_index_of(set,value);
    if( finder < set->count && set->cmp_fun(set->data[finder],value) == 0){
        return;
    }

    for (size_t i = set->count; i > finder;--i) {
        set->data[i] = set->data[i - 1];
    }
    set->data[finder] = value;
    set->count++;
    // TODO: use the set_index_of function to find where to insert value into the set's data

}

void set_remove(set_t *set, double value) {
    // TODO: use the set_index_of function to locate value in the set's data
    (void) set;
    (void) value;
  size_t finder =  set_index_of(set,value);
    if(finder < set->count && set->cmp_fun(set->data[finder],value) == 0) {
        for (size_t i = finder; i < set->count; i++) {
            set->data[i] = set->data[i + 1];
        }
        set->count--;
    }
}

bool set_contains(const set_t *set, double value) {
    // TODO: use binary search to locate value in the set's data
    (void) set;
    (void) value;

    for (size_t i = 0; i < set->count; i++) {
        if (set->cmp_fun(set->data[i], value) == 0) {
            return true;
        }
    }
    return false;
}

set_t *set_create(size_t init_cap, compare_fun_t cmp_fun) {
    return set_init((set_t *) malloc(sizeof(set_t)), init_cap, cmp_fun);
}

set_t *set_init(set_t *set, size_t init_cap, compare_fun_t cmp_fun) {
    if (set != NULL) {
        set->cmp_fun = cmp_fun;
        set->data = (double *) malloc(sizeof(double) * init_cap);
        set->count = 0;
        set->capacity = set->data != NULL ? init_cap : 0;
    }
    return set;
}

