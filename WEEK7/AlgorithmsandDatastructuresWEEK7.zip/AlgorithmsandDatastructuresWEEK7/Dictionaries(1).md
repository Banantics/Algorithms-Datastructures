# Week 7 - Dictionaries

## Team

>Members:
>
>- Member one
>- Member two
>
> Date: *day* *month* 2024

## Activities

Make sure to have the activities signed off regularly to ensure progress is tracked.

Download the provided project and open it in CLion.

### Activity 1: The ctype header file

isalpha(),tolower(),toupper():

int isalpha(int c): this checks if the character is a letter from a till z.

int tolower(int argument): this functions make the character  usually from the alphabet to lower case.

int toupper(int ch): this function makes the character usually from the alphabet to upper case.

### Activity 2: Count letters in a string

```c
unsigned long countLetters(unsigned long counts[static 26], const char* str) {
    ...
}

int main(void){
	unsigned long counts[26] = {0};
	const char* text = "The Quick Brown Fox Jumps Over The Lazy Dog.";
	unsigned long total = countLetters(&counts[0], text);
	assert(35 == total);
	printCounts(&counts[0], false, true);
}
```

### Activity 3: Recognizing languages

```c
const char* makeSignature(unsigned long counts[static 26]) {
    ...
}

int main(void) {
    unsigned long counts1[26] = {15,3,4,5,16,6,7,8,9,7,6,3,2,11,14,1,2,12,13};
	unsigned long counts2[26] = {16,4,7,5,20,7,4,3,14,5,9,1,2,18,6,12,9,13,9,15};
	assert(strcmp("eaosrn", makeSignature(counts1)) == 0);
	assert(strcmp("enatir", makeSignature(counts2)) == 0);
}
```

| File       | Signature | Language |
| ---------- | --------- |----------|
| alice0.txt | etaoin    | en       |
| alice1.txt |   iantes  | fi       |
| alice2.txt |eaionr     | it       |
| alice3.txt |  enisra   | de       |

### Activity 4: Find out: dictionaries in other languages

Python: Called a `dict`.
C#: Known as a `Dictionary`.
JavaScript: Objects (`{}`) and the `Map` object are used as dictionaries.
Java: The `HashMap` class functions similarly to a dictionary.
C++: Referred to as a `map`.

### Activity 5: Generic sorting in C

```c
int compare_strings(const void * pint1, const void* pint2) {
    const char * a = *(const char**) pint1;
    const char * b = *(const char**) pint2;

    return strcmp(a, b);
}

int main(void) {
     // TODO (Activity 5): create a generic function that compares two strings of which the address are passed,
    //  and use it to sort this array of strings using the qsort function
    const char * strings[] = {"Spam", "Cheese", "Knights", "Holy Grail", "Lumberjack", "Ministry", "Swallow",
                              "Silly", "Black Knight", "Camelot", "Coconut", "Parrot", "Shrubbery", "Taunt", "Argument"};

    qsort(strings, sizeof(strings) / sizeof(strings[0]), sizeof(strings[0]), compare_strings);  // TODO: exclude this line

    print_string_array(strings, sizeof(strings) / sizeof(const char*));
}
```
### Activity 6: Generic searching in C

```c
int main(void) {
      // TODO (Activity 5): create a generic function that compares two strings of which the address are passed,
    //  and use it to sort this array of strings using the qsort function
    const char * strings[] = {"Spam", "Cheese", "Knights", "Holy Grail", "Lumberjack", "Ministry", "Swallow",
                              "Silly", "Black Knight", "Camelot", "Coconut", "Parrot", "Shrubbery", "Taunt", "Argument"};

    qsort(strings, sizeof(strings) / sizeof(strings[0]), sizeof(strings[0]), compare_strings);  // TODO: exclude this line

    print_string_array(strings, sizeof(strings) / sizeof(const char*));

    // TODO (Activity 6): now use the binary_search function (in binsearch.h)
    //  to search the strings "Holy Grail", "Parrot", and "Rabbit"
    const char * targets[] = {"Holy Grail", "Parrot", "Rabbit"};
    for (size_t i = 0; i < sizeof(targets) / sizeof(targets[0]); ++i) {
        const char * target = targets[i];
        bsearch_result_t result = binary_search(&target, strings, sizeof(strings) / sizeof(strings[0]), sizeof(strings[0]), compare_strings);
        if (result.found) printf("Found %s at index %ld\n", target, result.index);
        else printf("Did not find %s\n", target);
    }
	return 0;
}
```

Record your answer here

### Activity 7: Counter - function implementations

```c
bool counter_contains_key(const counter_t *counter, const char *key) {
    (void) counter;
    (void) key;
    // TODO (Activity 7): use binary search to locate the item
    //  return true if it was found, false otherwise
    bsearch_result_t result = binary_search(&key, counter->data, counter->count, sizeof(pair_t), compare_strings);

    if (result.found) {
        return true;
    } else {
        return false;
    }
}

size_t counter_get_count(const counter_t *counter, const char *key) {
    (void) counter;
    (void) key;
    // TODO (Activity 7): use binary search to search the counter for a pair with the given key
    //  - if it was found, return the associated value


    bsearch_result_t result = binary_search(&key, counter->data, counter->count, sizeof(pair_t), compare_strings);

    if (result.found) {

        return counter->data[result.index].value;

    } else {
        return 0;
    }

}

void counter_remove_key(counter_t *counter, const char *key) {
    (void) counter;
    (void) key;

    bsearch_result_t result = binary_search(&key, counter->data, counter->count, sizeof(pair_t), compare_strings);
    if (result.found) {
    } else {
        return;
    }
    for (size_t i = result.index; i < counter->count; i++) {
        counter->data[i] = counter->data[i + 1];
    }

    counter->count--;
    // TODO (Activity 7): use binary search to locate the item
    //  if it was found, remove it from the counter
}

void counter_increment(counter_t *counter, const char *key) {
    (void) counter;
    (void) key;
    (void) _ensure_capacity;


    bsearch_result_t result = binary_search(&key, counter->data, counter->count, sizeof(pair_t), compare_strings);
    if (result.found) {
        counter->data[result.index].value++;
    } else {
        _ensure_capacity(counter);

        for (size_t i = counter->count; i > result.index; i--) {
            counter->data[i] = counter->data[i - 1];
        }

        counter->data[result.index].key = key;
        counter->data[result.index].value = 1;
        counter->count++;
    }
    // TODO (Activity 7): use binary search to search the counter for a pair with the given key
    //  - if it was found, increment the associated value
    //  - if it was not found, insert a new pair for the key such that the data remains sorted
    //    (make sure to ensure the counter has enough capacity by calling _ensure_capacity)
}

```

### Activity 8: Find out: function `strtok`

Record your answer here

### Activity 9: How many words?

Record your answer here

### Activity 10: Most frequent words

```c
int main(void) {

}
```

Record your answer here

## Looking back

### What we've learnt

Formulate at least one lesson learned.

### What were the surprises

Fill in...

### What problems we've encountered

Fill in...

### What was or still is unclear

Fill in...

### How did the group perform?

How was the collaboration? What were the reasons for hick-ups? What worked well? What can be improved next time?