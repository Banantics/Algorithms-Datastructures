//
// Created by rgr24 on 16/03/2024.
//

#include "pair.h"
#include <string.h>
#include <stdlib.h>

int compare_pairs(const pair_t* a, const pair_t* b) {
    return strcmp(a->key, b->key);
}

pair_t make_pair(const char *string) {
    char * buf = malloc(strlen(string) + 1);    // allocate enough memory to hold the string, including the terminating zero
    strcpy(buf, string);    // copy the string into the buffer
    pair_t result = { .key = buf, .value = 1 }; // create a pair_t with the string as key and a value of 1
    return result;
}

void destroy_pair(pair_t *pair) {
    free((void*) pair->key);    // deallocate the memory that was allocated for storing the key
    pair->key = NULL;           // set key to NULL to avoid dangling pointers
}
