#include <string.h>
#include <stdlib.h>
#include "counter.h"
#include "binsearch.h"


int compare_strings(const void *pint1, const void *pint2) {
    const char *a = *(const char **) pint1;
    const char *b = *(const char **) pint2;

    return strcmp(a, b);
}

/// Ensures that the counter can store at least one more element
/// \param counter The counter
/// \return true if the counter can store at least one more element, false otherwise
static bool _ensure_capacity(counter_t *counter) {
    if (counter->count < counter->capacity) return true;
    size_t cap = (counter->capacity + 1) * 3 / 2;
    void *ptr = realloc(counter->data, cap * sizeof(pair_t));
    if (ptr != NULL) {
        counter->data = ptr;
        counter->capacity = cap;
        return true;
    } else return false;
}

counter_t *counter_create(size_t init_cap) {
    return counter_init((counter_t *) malloc(sizeof(counter_t)), init_cap);
}

counter_t *counter_init(counter_t *counter, size_t init_cap) {
    if (counter != NULL) {
        counter->data = malloc(init_cap * sizeof(pair_t));
        counter->count = 0;
        counter->capacity = counter->data != NULL ? init_cap : 0;
    }
    return counter;
}

bool counter_contains_key(const counter_t *counter, const char *key) {
    (void) counter;
    (void) key;
    // TODO (Activity 7): use binary search to locate the item
    //  return true if it was found, false otherwise
    bsearch_result_t result = binary_search(&key, counter->data, counter->count, sizeof(pair_t), compare_strings);

    if (result.found) {
        return true;
    } else {
        return false;
    }
}

size_t counter_get_count(const counter_t *counter, const char *key) {
    (void) counter;
    (void) key;
    // TODO (Activity 7): use binary search to search the counter for a pair with the given key
    //  - if it was found, return the associated value


    bsearch_result_t result = binary_search(&key, counter->data, counter->count, sizeof(pair_t), compare_strings);

    if (result.found) {

        return counter->data[result.index].value;

    } else {
        return 0;
    }

}

void counter_remove_key(counter_t *counter, const char *key) {
    (void) counter;
    (void) key;

    bsearch_result_t result = binary_search(&key, counter->data, counter->count, sizeof(pair_t), compare_strings);
    if (result.found) {
    } else {
        return;
    }
    for (size_t i = result.index; i < counter->count; i++) {
        counter->data[i] = counter->data[i + 1];
    }

    counter->count--;
    // TODO (Activity 7): use binary search to locate the item
    //  if it was found, remove it from the counter
}

void counter_increment(counter_t *counter, const char *key) {
    (void) counter;
    (void) key;
    (void) _ensure_capacity;


    bsearch_result_t result = binary_search(&key, counter->data, counter->count, sizeof(pair_t), compare_strings);
    if (result.found) {
        counter->data[result.index].value++;
    } else {
        _ensure_capacity(counter);

        for (size_t i = counter->count; i > result.index; i--) {
            counter->data[i] = counter->data[i - 1];
        }

        counter->data[result.index].key = key;
        counter->data[result.index].value = 1;
        counter->count++;
    }
    // TODO (Activity 7): use binary search to search the counter for a pair with the given key
    //  - if it was found, increment the associated value
    //  - if it was not found, insert a new pair for the key such that the data remains sorted
    //    (make sure to ensure the counter has enough capacity by calling _ensure_capacity)
}

void counter_destroy(counter_t *counter) {
    // TODO (Activity 7): destroy data that was allocated for the counter, including keys
    counter->data = NULL;
    counter->capacity = counter->count = 0;
}
