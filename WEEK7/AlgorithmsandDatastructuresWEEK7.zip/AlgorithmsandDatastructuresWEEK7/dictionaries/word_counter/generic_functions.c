#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "binsearch.h"



// TODO: exclude this function
int compare_strings(const void * pint1, const void* pint2) {
    const char * a = *(const char**) pint1;
    const char * b = *(const char**) pint2;

    return strcmp(a, b);
}

void print_string_array(const char ** array, size_t count) {
    printf("[%s", array[0]);
    for (size_t i = 1; i < count; ++i) printf(", %s", array[i]);
    printf("]\n");
}

int main(void) {
    // TODO (Activity 5): crea
    //  e a generic function that compares two strings of which the address are passed,
    //  and use it to sort this array of strings using the qsort function
    const char * strings[] = {"Spam", "Cheese", "Knights", "Holy Grail", "Lumberjack", "Ministry", "Swallow",
                              "Silly", "Black Knight", "Camelot", "Coconut", "Parrot", "Shrubbery", "Taunt", "Argument"};

    qsort(strings, sizeof(strings) / sizeof(strings[0]), sizeof(strings[0]), compare_strings);  // TODO: exclude this line

    print_string_array(strings, sizeof(strings) / sizeof(const char*));

    // TODO (Activity 6): now use the binary_search function (in binsearch.h)
    //  to search the strings "Holy Grail", "Parrot", and "Rabbit"
    const char * targets[] = {"Holy Grail", "Parrot", "Rabbit"};
    for (size_t i = 0; i < sizeof(targets) / sizeof(targets[0]); ++i) {
        const char * target = targets[i];
        bsearch_result_t result = binary_search(&target, strings, sizeof(strings) / sizeof(strings[0]), sizeof(strings[0]), compare_strings);
        if (result.found) printf("Found %s at index %ld\n", target, result.index);
        else printf("Did not find %s\n", target);
    }
    return 0;
}
