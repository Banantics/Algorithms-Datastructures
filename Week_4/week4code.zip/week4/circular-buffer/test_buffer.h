#ifndef WEEK4_TEST_BUFFER_H
#define WEEK4_TEST_BUFFER_H

void test_buffer_get_write_idx(void);

void test_buffer_try_write(void);

void test_buffer_try_read(void);

#endif //WEEK4_TEST_BUFFER_H
