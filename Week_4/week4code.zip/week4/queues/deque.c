#include "deque.h"

bool try_read_deque(list_t *list, char *value) {
    (void) list;
    (void) value;
    // TODO: call list_try_remove & indicate from which end of the list
    //  the value must be removed (see list_of_char.h)
    //  choose either REAR or FRONT
    return false;
}

void  write_deque(list_t *list, char value) {
    (void) list;
    (void) value;
    // TODO: call list_add & indicate at which end of the list
    //  the value must be added (see list_of_char.h)
    //  choose either REAR or FRONT
}
