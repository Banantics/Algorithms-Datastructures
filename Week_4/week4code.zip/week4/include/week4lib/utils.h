#ifndef WEEK4_UTILS_H
#define WEEK4_UTILS_H

/// Returns a random double in range [0..1)
/// \return
double random_double(void);

#endif //WEEK4_UTILS_H
