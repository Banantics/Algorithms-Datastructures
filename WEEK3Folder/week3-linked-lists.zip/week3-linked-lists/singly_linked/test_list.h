//
// Created by rgr24 on 17/02/2023.
//

#ifndef SINGLY_LINKED_LISTS_TEST_LIST_H
#define SINGLY_LINKED_LISTS_TEST_LIST_H

void test_list_prepend(void);

void test_list_append(void);

void test_list_at(void);

void test_list_remove_first(void);

void test_list_remove_last(void);

#endif //SINGLY_LINKED_LISTS_TEST_LIST_H
