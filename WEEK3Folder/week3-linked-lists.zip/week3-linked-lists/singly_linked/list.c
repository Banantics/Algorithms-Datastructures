//
// Created by rgr24 on 17/02/2023.
//

#include "list.h"
#include <stdlib.h>

node_t *node_init(node_t *ptr, int value) {
    if (ptr != NULL) {
        ptr->next = NULL;
        ptr->value = value;
    }
    return ptr;
}

node_t *node_create(int value) {
    return node_init((node_t *) malloc(sizeof(node_t)), value);
}

list_t *list_init(list_t *plist) {
    if (plist != NULL) plist->head = NULL;
    return plist;
}

void list_destroy(list_t *plist) {
    (void) plist;
    // TODO: traverse the list and free all nodes (Activity 3)
}

void list_prepend(list_t *plist, int value) {
    node_t *node = node_create(value);
    if (node != NULL) {
        node->next = plist->head;
        plist->head = node;
    }
}

void list_append(list_t *plist, int value) {
    (void) plist;
    (void) value;
    // TODO: append value to the list by adding a new node after the last node (Activity 4)
}

const node_t * list_at(const list_t *plist, size_t index) {
    (void) plist;
    (void) index;
    // TODO: look up the node at the given index, and return it (Activity 6)
    return NULL;
}

bool list_remove_first(list_t *plist) {
    node_t *head = plist->head;
    if (head != NULL) plist->head = plist->head->next;
    free(head);
    return head != NULL;
}

bool list_remove_last(list_t *plist) {
    (void) plist;
    // TODO: remove the last node from the list (Activity 8)
    return false;
}

