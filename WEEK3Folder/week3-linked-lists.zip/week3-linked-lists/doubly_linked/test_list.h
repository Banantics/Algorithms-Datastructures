//
// Created by rgr24 on 17/02/2023.
//

#ifndef DOUBLY_LINKED_LISTS_TEST_LIST_H
#define DOUBLY_LINKED_LISTS_TEST_LIST_H

void test_list_prepend(void);

void test_list_append(void);

void test_list_remove(void);

void test_list_insert_before(void);

#endif //DOUBLY_LINKED_LISTS_TEST_LIST_H
