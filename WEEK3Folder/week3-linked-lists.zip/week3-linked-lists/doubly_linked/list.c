//
// Created by rgr24 on 17/02/2023.
//

#include "list.h"
#include <stdlib.h>

node_t *node_init(node_t *ptr, int value) {
    if (ptr != NULL) {
        ptr->next = NULL;
        ptr->prev = NULL;
        ptr->value = value;
    }
    return ptr;
}

node_t *node_create(int value) {
    return node_init( (node_t*) malloc(sizeof(node_t)), value);
}

list_t *list_init(list_t *plist) {
    if (plist != NULL) plist->head = plist->tail = NULL;
    return plist;
}

void list_prepend(list_t *plist, int value) {
    node_t * node = node_create(value);
    if (node != NULL) {
        // current head comes after node
        node->next = plist->head;

        // let the current head point back to the node
        if (plist->head != NULL) plist->head->prev = node;

        // update current head
        plist->head = node;

        // if the list was empty, then now it has a tail
        if (plist->tail == NULL) plist->tail = node;
    }
}

void list_append(list_t *plist, int value) {
    (void) plist;
    (void) value;
    // TODO: append value to the list (Activity 9)
}

void list_remove(list_t *plist, node_t *pnode) {
    (void) plist;
    (void) pnode;
    // TODO: remove the given node from the list (Activity 10)
}

void list_insert_before(list_t *plist, node_t *pnode, int value) {
    (void) plist;
    (void) pnode;
    (void) value;
    // TODO: insert the given value before the given node into the list (Activity 11)
}

